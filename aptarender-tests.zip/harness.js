// Loads index.html in jsdom and lets tests evaluate code inside the page's shared lexical scope.
const fs=require("fs"), {JSDOM}=require("jsdom");
function load(file, storage){
  const html=fs.readFileSync(file,"utf8");
  const errors=[];
  const dom=new JSDOM(html,{runScripts:"dangerously", pretendToBeVisual:true, url:"http://localhost/",
    beforeParse(w){
      Object.defineProperty(w.HTMLElement.prototype,"clientWidth",{get(){return 1000;}});
      Object.defineProperty(w.HTMLElement.prototype,"clientHeight",{get(){return 800;}});
      Object.defineProperty(w.Element.prototype,"clientWidth",{get(){return 1000;}});
      Object.defineProperty(w.Element.prototype,"clientHeight",{get(){return 800;}});
      w.URL.createObjectURL=()=>"blob:x"; w.URL.revokeObjectURL=()=>{};
      w.prompt=()=>null;
      if(storage) for(const k in storage) w.localStorage.setItem(k,storage[k]);
      w.addEventListener("error",e=>errors.push(e.message));
    }});
  const w=dom.window;
  function run(code){
    const s=w.document.createElement("script");
    s.textContent=`try{ window.__r=(function(){ ${code} })(); window.__e=null; }catch(e){ window.__e=String(e&&e.stack||e); }`;
    w.document.body.appendChild(s); s.remove();
    if(w.__e) throw new Error("in-page: "+w.__e);
    return w.__r;
  }
  return {w, run, errors, dom};
}
let fails=0;
function ok(c,msg){ if(c) console.log("  ok  "+msg); else { fails++; console.log("  FAIL "+msg); } }
module.exports={load, ok, done(){ console.log(fails?`\n${fails} FAILED`:"\nall passed"); process.exit(fails?1:0); }};
