const {load, ok, done}=require("./harness"); const fs=require("fs");
const file=process.argv[2];
const cases={
  hairpin:["GGGCAGCUUCGGCUGCCCAAAA","(((((((...))))))).....",],
  multiloop:["GGGGGGAAACCCGGGAAACCCGGGAAACCCCCC","((((((...)))[[[...]]](((...))))))"],
  twoStem:["AAAAGGGGAAACCCCUUUGGGGAAACCCCAAAA","....((((...))))...((((...))))...."],
  tails:["AAAAAGGGCAGCUUCGGCUGCCCAAAAA",".....(((((((...)))))))......"],
};
for(const [name,[s,d]] of Object.entries(cases)) for(const every of [1,5]){
  const {run,errors}=load(file);
  run(`$("seq").value="${s}"; $("dot").value="${d}"; $("cCircle").checked=true; $("numEvery").value=${every}; $("render").click();`);
  // measure: each label's clearance from every base circle, bond line, and other label
  const r=run(`
    const sts=strands(), P=displayPoints(sts), font=M.font, circR=font*0.72;
    const labs=[...placeNumberLabels(sts,P,${every},font,circR).entries()];
    const segs=[]; sts.forEach((st,s)=>{ for(let i=0;i<st.n;i++){ if(i<st.n-1) segs.push([P[s][i],P[s][i+1]]); if(st.pt[i]>i) segs.push([P[s][i],P[s][st.pt[i]]]); }});
    const sd=(c,[p,q])=>{const dx=q.x-p.x,dy=q.y-p.y,L2=dx*dx+dy*dy||1,u=Math.max(0,Math.min(1,((c.x-p.x)*dx+(c.y-p.y)*dy)/L2));return Math.hypot(c.x-p.x-u*dx,c.y-p.y-u*dy);};
    let worst=Infinity, leaders=0, far=0;
    labs.forEach(([k,L],idx)=>{
      const [s,i]=k.split(':').map(Number), txt=String(i+1), rl=Math.max(txt.length*font*0.5*0.62,font*0.5)/2;
      let c=Infinity;
      sts.forEach((st,ss)=>{ for(let j=0;j<st.n;j++) c=Math.min(c,Math.hypot(L.x-P[ss][j].x,L.y-P[ss][j].y)-circR); });
      for(const g of segs) c=Math.min(c,sd(L,g));
      labs.forEach(([k2,L2],j2)=>{ if(j2!==idx) c=Math.min(c,Math.hypot(L.x-L2.x,L.y-L2.y)-rl*2); });
      worst=Math.min(worst,c-rl); if(L.leader) leaders++;
      far=Math.max(far, Math.hypot(L.x-P[s][i].x,L.y-P[s][i].y)/font);
    });
    return {count:labs.length, worst:worst/font, leaders, far};`);
  ok(r.worst>=-0.02, `${name} every ${every}: ${r.count} labels, worst clearance ${r.worst.toFixed(2)}·font, leaders ${r.leaders}, farthest ${r.far.toFixed(2)}·font`);
  if(every===5||name==="multiloop") fs.writeFileSync(`nums/${name}_${every}.svg`, run(`return buildExportSVG().svg`));
  ok(errors.length===0,"no errors");
}
const {run}=load(file);
ok(run(`return document.getElementById("numOffset")===null && !STYLE_IDS.includes("numOffset")`), "offset numbering control removed");
done();
