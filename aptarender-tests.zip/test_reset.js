const {load, ok, done}=require("./harness");
const {run,errors}=load(process.argv[2]);
// 1. render resets rotation
run(`$("ex1").click(); $("rot").value=60; $("rot").oninput({target:$("rot")}); $("rot").onchange();`);
ok(run(`return M.rot`)===60, "rotated to 60°");
run(`$("render").click()`);
ok(run(`return M.rot===0 && $("rot").value==="0" && $("rotNum").value==="0"`), "clicking Render puts rotation back to 0°");
run(`$("rot").value=-30; $("rot").oninput({target:$("rot")}); $("rot").onchange(); addDoc("GGGAAACCC","(((...)))","new");`);
ok(run(`return M.rot===0`), "a newly added sequence starts at 0°");
run(`switchDoc(0)`); ok(run(`return M.rot===-30||M.rot===0`), "switching back keeps that sequence's own saved view");
// 2. reset to default
run(`$("ex1").click();
  M.selected.add(3); $("selColor").value="#123456"; $("applySel").click();
  $("selCircleColor").value="#abcdef"; $("applySelCircle").click();
  $("selSize").value=200; $("applySize").click();
  M.offX[5]=40; M.selBond.add(0); $("bondColor").value="#ff0000"; $("applyBond").click();
  $("font").value=30; $("font").oninput({target:$("font")}); $("font").onchange();
  $("cCircle").checked=true; $("cCircle").onchange();
  $("numEvery").value=5; $("numEvery").onchange();
  $("tailMode").value="perp"; $("tailMode").onchange();
  $("bgColor").value="#000000"; $("bgColor").oninput({target:$("bgColor")}); $("bgColor").onchange();
  $("rot").value=90; $("rot").oninput({target:$("rot")}); $("rot").onchange();`);
const custom=run(`return JSON.stringify([M.color[3],M.circleColor[3],M.size[3],M.offX[5],M.bondColor[0],M.font,$("cCircle").checked,$("numEvery").value,$("tailMode").value,$("bgColor").value,M.rot])`);
run(`$("resetAll").click()`);
const r=run(`return {c3:M.color[3], pal:M.palette[M.seq[3]], cc:Object.keys(M.circleColor).length, sz:Object.keys(M.size).length,
  off:M.offX.every(v=>v===0), bc:Object.keys(M.bondColor).length, font:M.font, circ:$("cCircle").checked, num:$("numEvery").value,
  tail:$("tailMode").value, bg:$("bgColor").value, rot:M.rot, sel:M.selected.size}`);
ok(r.c3===r.pal, "letter colors back to the palette");
ok(r.cc===0 && r.sz===0 && r.bc===0, "circle fills, sizes and bond colors cleared");
ok(r.off, "manual positions cleared");
ok(r.font===18 && r.circ===false && r.num==="0" && r.tail==="natural" && r.bg==="#ffffff", "style settings back to defaults (font 18, no circles, no numbering, Natural tails, white background)");
ok(r.rot===0 && r.sel===0, "rotation 0°, selection cleared");
run(`undo()`);
ok(run(`return JSON.stringify([M.color[3],M.circleColor[3],M.size[3],M.offX[5],M.bondColor[0],M.font,$("cCircle").checked,$("numEvery").value,$("tailMode").value,$("bgColor").value,M.rot])`)===custom, "one Undo brings every customization back");
// complex
run(`redo(); addDoc("GGGAAACCCUUUU","(((...)))....","h1"); addDoc("AAAAGGGUUUCCC","....(((...)))","h2");
  $("cxDocA").value=String(docs.length-2); $("cxDocB").value=String(docs.length-1);
  $("cxAStart").value=10; $("cxAEnd").value=13; $("cxBStart").value=1; $("cxBEnd").value=4; $("cxBuild").click();
  CM.selB.add(2); $("selColor").value="#00ff00"; $("applySel").click(); CM.offXA[1]=30; render();
  $("resetAll").click();`);
ok(run(`const s=strands(); return CM.active && s[1].color[2]===M.palette[s[1].seq[2]] && CM.offXA.every(v=>v===0)`), "Reset works on an open complex too");
ok(errors.length===0,"no page errors "+errors.join(";"));
done();
