const {load, ok, done}=require("./harness"); const fs=require("fs");
const file=process.argv[2]; const S=42;
const P_=load(file); const {run,w,errors}=P_;
const ev=(el,type,o)=>el.dispatchEvent(new w.MouseEvent(type,Object.assign({bubbles:true,cancelable:true},o||{})));
const svgEl=w.document.getElementById("canvas");
const hit=i=>w.document.querySelector(`circle.base-hit[data-s="0"][data-i="${i}"]`);
// screen position helpers
const scr=i=>run(`const p=displayPoints()[0][${i}]; return [M.panX+p.x*M.zoom, M.panY+p.y*M.zoom]`);
const eff=()=>run(`const st=strands()[0]; const o=[]; for(let i=0;i<st.n;i++) o.push([effX(st,i),effY(st,i)]); return o`);
const dist=(a,b)=>Math.hypot(a[0]-b[0],a[1]-b[1]);
function minPair(E){ let m=1e9; for(let i=0;i<E.length;i++)for(let j=i+1;j<E.length;j++) m=Math.min(m,dist(E[i],E[j])); return m; }

/* ===== 1. Ring rotation ===== */
const dot="((((((........((((((((......))))))))....))))))";
run(`$("seq").value="${"GGGGGGAAAAAAAACCCCGGGGAAAAAACCCCGGGGAAAACCCCCC"}"; $("dot").value="${dot}"; $("render").click();`);
run(`$("ringLockBtn").click()`);
ok(run(`return ringLock===null && /Select a ring first/.test($("ringInfo").textContent)`), "Lock ring without a ring selected explains what to do");
// ctrl+click unpaired base 8 (in the internal loop) then lock
ev(hit(8),"mousedown",{ctrlKey:true,clientX:5,clientY:5}); ev(w,"mouseup",{clientX:5,clientY:5});
run(`$("ringLockBtn").click()`);
ok(run(`return ringLock && ringLock.ci===5`), "Ctrl+click ring + Lock ring locks the loop closed by bases 6–41");
const ring=run(`return ringModel(M.pt,ringLock.ci)`);
const members=ring.seqOrder, unp=ring.gaps.flat();
const E0=eff();
const fit0=run(`const st=strands()[0]; return circleFit(${JSON.stringify(members)}.map(i=>({x:effX(st,i),y:effY(st,i)})))`);
const cx=fit0.cx, cy=fit0.cy, R0=fit0.R;
// drag a base in the inner helix (index 16) around the ring center by ~40 degrees
const cS=run(`const D=displayPoints()[0]; let x=0,y=0; ${JSON.stringify(members)}.forEach(i=>{x+=D[i].x;y+=D[i].y;}); x/=${members.length}; y/=${members.length}; return [M.panX+x*M.zoom, M.panY+y*M.zoom]`);
const s16=scr(16); const r16=dist(s16,cS), a16=Math.atan2(s16[1]-cS[1],s16[0]-cS[0]);
const at=a=>({clientX:cS[0]+r16*Math.cos(a), clientY:cS[1]+r16*Math.sin(a)});
ev(hit(16),"mousedown",at(a16));
for(let k=1;k<=8;k++) ev(w,"mousemove",at(a16+k*0.05));
ev(w,"mouseup",at(a16+0.4));
const E1=eff();
let maxDev=0; members.forEach(i=>maxDev=Math.max(maxDev,Math.abs(dist(E1[i],[cx,cy])-R0)));
ok(maxDev<1e-6, `every ring base stays on the same circle (max radius change ${maxDev.toExponential(1)})`);
const helix=[]; for(let i=14;i<=35;i++) helix.push(i);
let rigid=0; for(const i of helix) for(const j of helix) rigid=Math.max(rigid,Math.abs(dist(E1[i],E1[j])-dist(E0[i],E0[j])));
ok(rigid<1e-6, "dragged helix moves rigidly (with its hairpin)");
const turned=Math.atan2(E1[14][1]-cy,E1[14][0]-cx)-Math.atan2(E0[14][1]-cy,E0[14][0]-cx);
ok(Math.abs(turned)>0.3 && Math.abs(turned)<=0.4+1e-9, `helix swung around the ring, up to the neighbour clamp (${Math.abs(turned).toFixed(3)} of 0.4 rad)`);
let fixed=0; for(let i=0;i<=5;i++) fixed=Math.max(fixed,dist(E1[i],E0[i])); for(let i=41;i<46;i++) fixed=Math.max(fixed,dist(E1[i],E0[i]));
ok(fixed<1e-9, "the rest of the molecule stays put");
// even spacing inside each arc
for(const run_ of ring.gaps){ if(run_.length<2) continue;
  const ds=[]; for(let q=0;q<run_.length-1;q++) ds.push(dist(E1[run_[q]],E1[run_[q+1]]));
  ok(Math.max(...ds)-Math.min(...ds)<1e-6, `arc of ${run_.length} unpaired bases is evenly re-spaced (${ds[0].toFixed(1)} px)`); }
ok(minPair(E1)>0.7*S, `no overlapping bases after the swing (closest ${(minPair(E1)/S).toFixed(2)}·spacing)`);
ok(run(`return histIndex`)>0, "the swing is one undo step");
// drag way too far: clamped so the helix can't pass its neighbour
ev(hit(16),"mousedown",at(a16+0.4));
for(let k=1;k<=60;k++) ev(w,"mousemove",at(a16+0.4+k*0.08));
ev(w,"mouseup",at(a16+0.4+4.8));
const E2=eff();
ok(minPair(E2)>0.7*S, `dragging far past a neighbour is clamped — still no overlaps (closest ${(minPair(E2)/S).toFixed(2)}·spacing)`);
let dev2=0; members.forEach(i=>dev2=Math.max(dev2,Math.abs(dist(E2[i],[cx,cy])-R0)));
ok(dev2<1e-6, "ring radius unchanged after a clamped drag");
// drag the outer part (base 2) -> rest rotates, inner helix fixed
const s2=scr(2); const r2=dist(s2,cS), a2=Math.atan2(s2[1]-cS[1],s2[0]-cS[0]);
ev(hit(2),"mousedown",{clientX:s2[0],clientY:s2[1]});
for(let k=1;k<=5;k++) ev(w,"mousemove",{clientX:cS[0]+r2*Math.cos(a2+k*0.05),clientY:cS[1]+r2*Math.sin(a2+k*0.05)});
ev(w,"mouseup",{});
const E3=eff();
let innerFixed=0; for(const i of helix) innerFixed=Math.max(innerFixed,dist(E3[i],E2[i]));
ok(innerFixed<1e-9 && dist(E3[2],E2[2])>5, "dragging the outer stem swings the rest of the molecule; inner helix stays");
ok(minPair(E3)>0.7*S, "no overlaps after swinging the outer stem");
// trying to drag a locked ring base does nothing
const before=JSON.stringify(eff()); const s8=scr(8);
ev(hit(8),"mousedown",{clientX:s8[0],clientY:s8[1]}); ev(w,"mousemove",{clientX:s8[0]+40,clientY:s8[1]}); ev(w,"mouseup",{});
ok(JSON.stringify(eff())===before && /ring itself is locked/.test(run(`return $("ringInfo").textContent`)), "ring bases themselves are locked");
// undo back to the start, Esc unlocks
run(`undo(); undo(); undo();`);
ok(dist(eff()[16],E0[16])<1e-6, "undo restores the original layout");
w.document.body.focus(); w.dispatchEvent(new w.KeyboardEvent("keydown",{key:"Escape",bubbles:true}));
ok(run(`return ringLock===null && $("ringLockBtn").textContent==="Lock ring"`), "Esc unlocks the ring");
// multiloop: swing one of three helices, the others stay
run(`$("ex2").click(); M.selected.clear(); M.selected.add(6); $("ringLockBtn").click();`);
const ml=run(`return ringLock? ringModel(M.pt,ringLock.ci):null`);
ok(ml && ml.ci===0 ? false : !!ml, "hairpin-loop ring lock works too");
run(`unlockRing(); M.selected.clear();`);
// junction bases of the multiloop ex2 have no unpaired bases (((...)))(((...)))... so use a custom multiloop
run(`$("seq").value="GGGAAGGGAAACCCAAGGGAAACCCAAGGGAAACCCAACCC"; $("dot").value="(((..(((...)))..(((...)))..(((...)))..)))"; $("render").click();`);
run(`M.selected.add(3); $("ringLockBtn").click();`);
const mm=run(`return ringModel(M.pt,ringLock.ci)`);
ok(mm.children.length===3, "multiloop ring with 3 helices locked");
const F0=eff(); const sX=scr(20);
let mc=[0,0]; const mD=run(`const D=displayPoints()[0]; let x=0,y=0; ${JSON.stringify(mm.seqOrder)}.forEach(i=>{x+=D[i].x;y+=D[i].y;}); x/=${mm.seqOrder.length}; y/=${mm.seqOrder.length}; return [M.panX+x*M.zoom, M.panY+y*M.zoom]`);
const rr=dist(sX,mD), aa=Math.atan2(sX[1]-mD[1],sX[0]-mD[0]);
ev(hit(20),"mousedown",{clientX:sX[0],clientY:sX[1]});
for(let k=1;k<=6;k++) ev(w,"mousemove",{clientX:mD[0]+rr*Math.cos(aa+k*0.04),clientY:mD[1]+rr*Math.sin(aa+k*0.04)});
ev(w,"mouseup",{});
const F1=eff();
let other=0; for(const i of [5,6,7,11,12,13,27,30,35]) other=Math.max(other,dist(F1[i],F0[i]));
ok(other<1e-9 && dist(F1[20],F0[20])>5, "multiloop: only the dragged helix moves; the other two stay");
ok(minPair(F1)>0.7*S, "multiloop: no overlaps");
fs.writeFileSync("newf/ring_multiloop.svg", run(`return buildExportSVG().svg`));
run(`unlockRing()`);

/* ===== 2. Per-base size ===== */
run(`$("ex1").click(); M.selected.clear(); [7,8,9].forEach(i=>M.selected.add(i)); $("cCircle").checked=true;
     $("selSize").value=200; $("selSize").oninput({target:$("selSize")}); $("applySize").click();`);
const svgTxt=run(`return buildExportSVG().svg`);
const font=run(`return M.font`);
ok((svgTxt.match(new RegExp(`font-size="${font*2}"`,"g"))||[]).length===3, "3 selected letters drawn at 200% font size");
ok((svgTxt.match(new RegExp(`r="${font*0.72*2}"`,"g"))||[]).length===3, "their circles scale with them");
ok(run(`return M.size[8]===2 && M.size[0]===undefined`), "other bases keep normal size");
const st1=run(`persist(); return localStorage.getItem("aptarender_docs")`);
const R2=load(file,{aptarender_docs:st1});
ok(R2.run(`return M.size[8]===2`), "sizes survive a reload");
run(`undo()`); ok(run(`return !M.size[8]`), "size change is undoable");
run(`redo(); $("resetSize").click()`); ok(run(`return Object.keys(M.size).length===0`), "Reset all sizes");
run(`M.selected.clear(); $("applySize").click()`); ok(/Select some bases/.test(run(`return $("sizeInfo").textContent`)), "size with nothing selected explains");
// font slider still changes everything
run(`M.selected.add(3); $("applySize").click(); $("font").value=24; $("font").oninput({target:$("font")});`);
ok(run(`return buildExportSVG().svg.includes('font-size="48"') && buildExportSVG().svg.includes('font-size="24"')`), "global font size still scales everything, including enlarged bases");
run(`$("font").value=18; $("font").oninput({target:$("font")}); $("resetSize").click()`);

/* ===== 3. Color file ===== */
const sample=run(`return colorSampleText()`);
fs.writeFileSync("newf/sample_from_app.txt", sample);
run(`applyColorFile(${JSON.stringify(sample)})`);
ok(run(`return M.color[0]==="#3b6fb6" && M.color[8]==="#e8833a" && M.color[20]==="#8a93a3"`), "sample file round-trips: stems blue, loop orange, free end gray");
ok(/Colored 22 bases/.test(run(`return $("colorFileInfo").textContent`)), "reports how many were colored");
const custom=["position color","# comment","1 #ff0000","2-4 steelblue circle","5, G, #0f0, both","6 C red","7 notacolor","99 #000","B:3 #123456","10 A #00f letters"].join("\n");
run(`$("cCircle").checked=false; applyColorFile(${JSON.stringify(custom)})`);
const res=run(`return {c0:M.color[0], cc2:M.circleColor[1], cc4:M.circleColor[3], c2:M.color[1], c5:M.color[4], cc5:M.circleColor[4], c6:M.color[5], c10:M.color[9], circ:$("cCircle").checked, info:$("colorFileInfo").textContent}`);
ok(res.c0==="#ff0000", "plain 'position color' line");
ok(res.cc2==="steelblue" && res.cc4==="steelblue" && res.c2!=="steelblue", "range + named color + circle target");
ok(res.c5==="#0f0" && res.cc5==="#0f0", "comma-separated line with base letter and 'both'");
ok(res.c10==="#00f", "'letters' target accepted");
ok(res.circ, "turns circles on when circle colors are applied");
ok(/Skipped 3/.test(res.info) && /notacolor/.test(res.info), "bad color, out-of-range and B: lines are reported, not applied: "+res.info);
ok(/didn't match at 5 \(file G, sequence A\)/.test(res.info), "base-letter mismatch is flagged");
ok(run(`undo(); return true`), "undo after color file");
// complex with A:/B:
run(`addDoc("GGGAAACCCUUUU","(((...)))....","h1"); addDoc("AAAAGGGUUUCCC","....(((...)))","h2");
  $("cxDocA").value=String(docs.length-2); $("cxDocB").value=String(docs.length-1);
  $("cxAStart").value=10; $("cxAEnd").value=13; $("cxBStart").value=1; $("cxBEnd").value=4; $("cxBuild").click();
  applyColorFile("A:1 #111111\\nB:2 #222222\\n3 #333333");`);
ok(run(`const sts=strands(); return sts[0].color[0]==="#111111" && sts[1].color[1]==="#222222" && sts[0].color[2]==="#333333"`), "complex: A:/B: prefixes pick the strand (no prefix = A)");
ok(/^A:1 /m.test(run(`return colorSampleText()`)) && /^B:13 /m.test(run(`return colorSampleText()`)), "sample in a complex lists both strands with A:/B:");
ok(errors.length===0, "no page errors "+errors.join(";"));
done();
