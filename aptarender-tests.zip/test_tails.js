const {load, ok, done}=require("./harness");
const {run}=load(process.argv[2]);
run(`$("seq").value="AAAAGGGGAAACCCCUUUGGGGAAACCCCAAAA"; $("dot").value="....((((...))))...((((...))))...."; $("render").click();`);
const modes=["natural","flatten","L","perp"], shapes={};
for(const m of modes){ run(`$("tailMode").value="${m}"; $("tailMode").onchange();`); shapes[m]=run(`return JSON.stringify([M.x,M.y])`); }
ok(new Set(Object.values(shapes)).size===4, "all four tail styles give distinct layouts on a two-stem aptamer");
// natural tails curve toward the stems (stems grow toward -y)
run(`$("tailMode").value="natural"; $("tailMode").onchange();`);
ok(run(`return M.y[0]<M.y[4] && M.y[32]<M.y[28]`), "natural: both free ends curve up toward the stems");
// tail drag offsets cleared on style change; stem offsets kept
run(`M.offX[0]=30; M.offX[10]=25; $("tailMode").value="flatten"; $("tailMode").onchange();`);
ok(run(`return M.offX[0]===0 && M.offX[10]===25`), "style change clears tail-base drags, keeps stem drags");
ok(run(`return histIndex>0 && JSON.parse(localStorage.getItem("aptarender_docs")).style.tailMode==="flatten"`), "style change is saved and undoable");
done();
