// overlap + bond-length + tail-tip separation, for every case/mode
const o=require(process.argv[2]); const S=42; let bad=0;
for(const [k,{x,y}] of Object.entries(o)){
  const n=x.length, clash=[];
  for(let i=0;i<n;i++)for(let j=i+1;j<n;j++) if(Math.hypot(x[i]-x[j],y[i]-y[j])<0.85*S) clash.push(i+"/"+j);
  let maxB=0,minB=9; for(let i=0;i<n-1;i++){ const b=Math.hypot(x[i+1]-x[i],y[i+1]-y[i])/S; maxB=Math.max(maxB,b); minB=Math.min(minB,b); }
  const tip=Math.hypot(x[0]-x[n-1],y[0]-y[n-1])/S;
  const ok=!clash.length && minB>0.98; if(!ok) bad++;
  if(k.endsWith("natural")||!ok) console.log((ok?"  ok  ":"  FAIL")+` ${k.padEnd(18)} n=${n} bond ${minB.toFixed(2)}-${maxB.toFixed(2)}S  5'-3' tips ${tip.toFixed(2)}S ${clash.slice(0,6).join(" ")}`);
}
console.log(bad?bad+" FAILED":"all clean (no two bases closer than 0.85 spacing)");
