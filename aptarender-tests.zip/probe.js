// Probes suspected bugs + captures export snapshots of the ORIGINAL file for later comparison.
const {load, ok, done}=require("./harness");
const file=process.argv[2]; const out=process.argv[3];
const fs=require("fs");
const A=load(file);
const snap={};
// single-sequence export
A.run(`$("seq").value="GGGCAGCUUCGGCUGCCCAAAA"; $("dot").value="(((((((...))))))).....";
       $("numEvery").value=5; $("render").click();`);
snap.single=A.run(`return buildExportSVG().svg`);
// two strands + side complex
A.run(`addDoc("GGGAAACCCUUUU","(((...)))....","h1"); addDoc("AAAAGGGUUUCCC","....(((...)))","h2");
  $("cxDocA").value="1"; $("cxDocB").value="2";
  $("cxAStart").value=10; $("cxAEnd").value=13; $("cxBStart").value=1; $("cxBEnd").value=4;
  $("cxMode").value="side"; $("cxBuild").click();`);
snap.complexSide=A.run(`return buildExportSVG().svg`);
const modeBefore=A.run(`return complexes[0].mode`);
const stored=A.run(`persist(); return localStorage.getItem("aptarender_docs")`);
const B=load(file,{aptarender_docs:stored});
const modeAfter=B.run(`return complexes[0].mode`);
ok(modeBefore===modeAfter, `complex mode survives reload (${modeBefore} -> ${modeAfter})`);

// undo of a style change under uniform mode
const C=load(file);
C.run(`$("render").click(); $("cCircle").checked=true; $("cCircle").onchange();`);
const circlesOn=C.run(`return $("cCircle").checked`);
C.run(`undo()`);
ok(circlesOn && C.run(`return $("cCircle").checked`)===false, `undo reverts a style toggle (uniform mode)`);
// style persists across reload
C.run(`redo(); persist();`);
const D=load(file,{aptarender_docs:C.run(`return localStorage.getItem("aptarender_docs")`)});
ok(D.run(`return $("cCircle").checked`)===true, `style toggle survives reload (uniform mode)`);
// complex view keeps rendering after window resize
ok(A.errors.length===0 && B.errors.length===0, "no page errors: "+A.errors.concat(B.errors).join(";"));
if(out) fs.writeFileSync(out, JSON.stringify(snap));
done();
