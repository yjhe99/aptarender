const {load, ok, done}=require("./harness");
const file=process.argv[2];
const P=load(file);
const {run,w}=P;
const ev=(el,type,o)=>el.dispatchEvent(new w.MouseEvent(type,Object.assign({bubbles:true,cancelable:true},o||{})));
const baseEl=(s,i)=>w.document.querySelector(`circle.base-hit[data-s="${s}"][data-i="${i}"]`);

// ---------- partIndicesIn ----------
//            0123456789012345678901234567890
const dot  = "..((((...))((...))))...";
run(`$("seq").value="${"G".repeat(dot.length)}"; $("dot").value="${dot}"; $("render").click();`);
const part=i=>run(`return partIndicesIn(M.pt,${i}).join(",")`);
ok(part(3)==="2,3,18,19", "stem part = outer helix both rails ("+part(3)+")");
ok(part(7)==="6,7,8", "ring part = hairpin loop ("+part(7)+")");
ok(part(0)==="0,1", "free part = 5' tail ("+part(0)+")");
ok(part(21)==="20,21,22", "free part = 3' tail ("+part(21)+")");
// multiloop ring: unpaired bases directly inside 3..17? there are none between 5..10 and 11..16 except none → check bulge-free; use another
const ml="((..((...))..((...))..))";
run(`$("seq").value="${"A".repeat(ml.length)}"; $("dot").value="${ml}"; $("render").click();`);
ok(part(2)==="2,3,11,12,20,21", "multiloop ring skips enclosed stems ("+part(2)+")");
ok(part(12)===part(2), "ring found from a base after a nested stem");

// ---------- Ctrl+click selects a part, Ctrl+drag moves only that part ----------
run(`$("ex1").click();`);   // GGGCAGCUUCGGCUGCCCAAAA / (((((((...))))))).....
ev(baseEl(0,8),"mousedown",{ctrlKey:true,clientX:10,clientY:10}); ev(w,"mouseup",{clientX:10,clientY:10});
ok(run(`return [...M.selected].sort((a,b)=>a-b).join(",")`)==="7,8,9", "Ctrl+click on loop selects the ring");
const before=run(`return [M.offX.slice(),M.offY.slice()]`);
ev(baseEl(0,19),"mousedown",{ctrlKey:true,clientX:0,clientY:0});
ev(w,"mousemove",{clientX:50,clientY:0}); ev(w,"mouseup",{clientX:50,clientY:0});
const moved=run(`return M.offX.map((v,i)=>v!==0?i:-1).filter(i=>i>=0).join(",")`);
ok(moved==="17,18,19,20,21", "Ctrl+drag moves only the 3' free run ("+moved+")");
ok(run(`return histIndex>0`), "part drag recorded an undo step");

// ---------- dragging a selected base moves whole selection ----------
run(`M.offX.fill(0); M.offY.fill(0); M.selected.clear(); [0,1,20].forEach(i=>M.selected.add(i)); render();`);
ev(baseEl(0,1),"mousedown",{clientX:0,clientY:0}); ev(w,"mousemove",{clientX:0,clientY:30}); ev(w,"mouseup",{clientX:0,clientY:30});
ok(run(`return M.offY.map((v,i)=>v!==0?i:-1).filter(i=>i>=0).join(",")`)==="0,1,20", "drag of selected base moves the selection");

// ---------- rotateSelection ----------
run(`M.offX.fill(0); M.offY.fill(0); M.selected.clear(); for(let i=0;i<=16;i++) M.selected.add(i); render();`);
const dist=(a,b)=>run(`const st=strands()[0]; return Math.hypot(effX(st,${a})-effX(st,${b}), effY(st,${a})-effY(st,${b}))`);
const d0=dist(3,12), piv0=run(`const st=strands()[0]; return [(effX(st,0)+effX(st,16))/2,(effY(st,0)+effY(st,16))/2]`);
const dir0=run(`const st=strands()[0]; return Math.atan2(effY(st,8)-effY(st,0), effX(st,8)-effX(st,0))*180/Math.PI`);
run(`$("rotSelDeg").value=90; $("rotSelPivot").value="attach"; $("rotSelGo").click();`);
const dir1=run(`const st=strands()[0]; return Math.atan2(effY(st,8)-effY(st,0), effX(st,8)-effX(st,0))*180/Math.PI`);
const piv1=run(`const st=strands()[0]; return [(effX(st,0)+effX(st,16))/2,(effY(st,0)+effY(st,16))/2]`);
ok(Math.abs(dist(3,12)-d0)<1e-6, "rotation is rigid (pairwise distances kept)");
let dd=((dir1-dir0)%360+360)%360;
ok(Math.abs(dd-90)<1e-6, `rotated by +90° (got ${dd.toFixed(2)})`);
ok(Math.hypot(piv1[0]-piv0[0],piv1[1]-piv0[1])<1e-6, "attach-point pivot (base rung midpoint) stays fixed");
ok(run(`return M.offX[20]===0 && M.offY[20]===0`), "unselected bases untouched");
run(`undo()`);
ok(run(`return M.offX.every(v=>v===0)`), "undo reverts the rotation");

// ---------- zoom to selection ----------
run(`fit();`); const zFit=run(`return M.zoom`);
run(`M.selected.clear(); M.selected.add(8); zoomToSelection();`);
const z=run(`return M.zoom`), c=run(`const P=displayPoints()[0][8]; return [M.panX+P.x*M.zoom, M.panY+P.y*M.zoom]`);
ok(z>zFit && z<=30, `zoom-to-selection zooms in (${zFit.toFixed(2)} -> ${z.toFixed(2)})`);
ok(Math.abs(c[0]-500)<1 && Math.abs(c[1]-400)<1, "selected base centered on canvas");
run(`M.selected.clear(); zoomToSelection();`);
ok(Math.abs(run(`return M.zoom`)-zFit)<1e-9, "empty selection falls back to Fit");

// ---------- marquee ----------
run(`fit(); M.selected.clear();`);
const svgEl=w.document.getElementById("canvas");
ev(svgEl,"mousedown",{shiftKey:true,clientX:0,clientY:0});
ev(w,"mousemove",{clientX:1000,clientY:800});
ok(!!svgEl.querySelector('rect[stroke-dasharray="4,3"]'), "marquee rectangle drawn while dragging");
ev(w,"mouseup",{clientX:1000,clientY:800});
ok(run(`return M.selected.size===M.n`), "marquee over whole canvas selects every base");
ok(!svgEl.querySelector('rect[stroke-dasharray="4,3"]'), "marquee rect removed after release");

// ---------- complex: non-WC dashes, numbering, color edits survive, return to single view ----------
run(`addDoc("GGGAAACCCUUUU","[[[...]]]....","h1"); addDoc("AAAAGGGUUUCCC","....(((...)))","h2");
  $("cxDocA").value="1"; $("cxDocB").value="2";
  $("cxAStart").value=10; $("cxAEnd").value=13; $("cxBStart").value=1; $("cxBEnd").value=4;
  $("cxMode").value="side"; $("cxBuild").click();`);
ok(run(`return CM.active`), "complex built");
const dashed=run(`return buildExportSVG().svg.split("\\n").filter(l=>l.includes("stroke-dasharray")).length`);
ok(dashed===3, "complex export draws strand A's 3 non-WC rungs dashed ("+dashed+")");
run(`$("numEvery").value=5; render();`);
ok(run(`return buildExportSVG().svg.includes(">10</text>")`), "complex view now shows numbering");
run(`CM.selA.add(0); $("selColor").value="#123456"; $("applySel").click();`);
ok(run(`return docs[1].color[0]`)==="#123456", "complex letter color written to strand A's doc");
run(`$("cxBuild").click();`);   // used to call saveActive() and overwrite docs[active] with stale M
run(`switchDoc(1);`);
ok(run(`return !CM.active && M.color[0]==="#123456"`), "complex color edit survives rebuilding + switching back");
run(`openComplex(0); switchDoc(active);`);
ok(run(`return !CM.active`), "clicking the active doc while in a complex returns to its single view");

// ---------- slider change is undoable ----------
const f0=run(`return $("font").value`);
run(`$("font").value=30; $("font").oninput({target:$("font")}); $("font").onchange();`);
run(`undo()`);
ok(run(`return $("font").value`)===f0 && run(`return M.font`)===+f0, "undo reverts font-size slider");

ok(P.errors.length===0, "no page errors "+P.errors.join(";"));
done();
