const {load, ok, done}=require("./harness");
const file=process.argv[2];
const P_=load(file); const {run,w,errors}=P_;
/* 1b: hidden characters from PowerPoint/Word */
const seq="GGGCAGCUUCGGCUGCCCAAAA", dot="(((((((...))))))).....";
const dirty=[
  ["zero-width space",   s=>s.slice(0,5)+"​"+s.slice(5)],
  ["byte-order mark",    s=>"﻿"+s],
  ["soft hyphen",        s=>s.slice(0,8)+"­"+s.slice(8)],
  ["non-breaking space", s=>s.slice(0,3)+" "+s.slice(3)],
  ["line separator",     s=>s+" "],
  ["direction marks",    s=>"‎"+s+"‏"],
  ["word joiner",        s=>s.slice(0,10)+"⁠"+s.slice(10)],
  ["CRLF + tab",         s=>s.slice(0,11)+"\r\n\t"+s.slice(11)],
];
for(const [name,f] of dirty){
  const r=run(`try{ const p=parseStructure(${JSON.stringify(f(seq))}, ${JSON.stringify(f(dot))}); return p.n; }catch(e){ return String(e); }`);
  ok(r===22, `${name} in both boxes is ignored (${r})`);
}
// PowerPoint autocorrect: "..." -> "…", full-width parentheses
const pptDot=dot.replace("...","…").replace(".....","…..");
ok(run(`return parseStructure(${JSON.stringify(seq)}, ${JSON.stringify(pptDot)}).n`)===22, "autocorrected '…' ellipsis in the structure is read as '...'");
ok(run(`return parseStructure("GGGAAACCC", "（（（...）））").n`)===9, "full-width （ ） brackets are read as ( )");
ok(run(`try{ parseStructure("GGXAAACCC","(((...)))"); }catch(e){ return String(e); }`).includes('"X" at position 3'), "a real wrong letter is still reported, with its position");
ok(/U\+00A9|"©"/.test(run(`try{ parseStructure("GG©AAACCC","(((...)))"); }catch(e){ return String(e); }`)), "odd visible symbols are named in the error");
// paste into the box cleans what's displayed
run(`const ta=$("seq"); ta.value=""; ta.focus();
  const ev=new Event("paste",{bubbles:true,cancelable:true}); ev.clipboardData={getData:()=>"GGG​CAG﻿"}; ta.dispatchEvent(ev);`);
ok(run(`return $("seq").value`)==="GGGCAG", "pasting into the Sequence box strips hidden characters right away");
// full UI render with a dirty paste
run(`$("seq").value=${JSON.stringify(dirty[0][1](seq))}; $("dot").value=${JSON.stringify(pptDot)}; $("render").click();`);
ok(run(`return $("err").textContent===""&&M.n===22`), "Render works with a PowerPoint-style paste");
/* 1a: wrapping */
const css=run(`const s=getComputedStyle($("seq")); return [s.whiteSpace, s.wordBreak]`);
ok(css[0]==="pre-wrap" && css[1]==="break-all", "long sequences wrap inside the boxes ("+css.join(", ")+")");
/* 2: rotation both ways */
ok(run(`return $("rot").min==="-360" && $("rot").max==="360" && $("rot").value==="0"`), "rotation slider runs -360° to 360°, starting at 0 in the middle");
run(`$("rot").value=-45; $("rot").oninput({target:$("rot")}); $("rot").onchange();`);
ok(run(`return M.rot===-45 && $("rotNum").value==="-45"`), "can rotate counter-clockwise from 0");
const st=run(`persist(); const s=JSON.parse(localStorage.getItem("aptarender_docs")); s.docs[s.active].view={zoom:1,panX:0,panY:0,rot:270}; return JSON.stringify(s)`);
const B=load(file,{aptarender_docs:st});
ok(B.run(`return M.rot===270 && $("rot").value==="270" && $("rotNum").value==="270"`), "a 270° save opens as 270° — slider and box agree");
/* 3: export file name */
const names=[];
run(`window.__names=[]; HTMLAnchorElement.prototype.click=function(){ window.__names.push(this.download); };`);
run(`docs[active].name="Thrombin aptamer"; $("expName").value=""; $("expSvg").click();`);
run(`$("expName").value="Figure 2b.svg"; $("expSvg").click();`);
run(`$("expName").value='bad/na:me*?'; $("expSvg").click();`);
const got=run(`return window.__names`);
ok(got[0]==="Thrombin aptamer.svg", "blank name uses the sequence's name: "+got[0]);
ok(got[1]==="Figure 2b.svg", "typed name is used, extension not doubled: "+got[1]);
ok(got[2]==="bad_na_me_.svg", "characters files can't contain are replaced: "+got[2]);
ok(run(`updateExportInfo(); return $("expName").placeholder`)==="Thrombin aptamer", "the box shows the default name as a hint");
ok(run(`return $("expAsk").disabled===true`), "Save-dialog option is disabled where the browser can't do it (jsdom)");
ok(errors.length===0,"no page errors "+errors.join(";"));
done();
