// Renders every tail mode for several structures through the real UI, saves SVGs.
const {load}=require("./harness"); const fs=require("fs");
const file=process.argv[2], tag=process.argv[3]||"x";
const cases={
  hpUneq:["AAGGGCAGCUUCGGCUGCCCAAAAAAAAA","..(((((((...))))))).........."],
  hpLong:["AAAAAAAAAAAAAAAAAAAAGGGCAGCUUCGGCUGCCCAAAAAAAAAAAAAAAAAAAA","....................(((((((...)))))))....................."],
  hp1:["AGGGCAGCUUCGGCUGCCCA",".(((((((...))))))).."],
  twoLong:["AAAAAAAAAAAAGGGGAAACCCCUUUGGGGAAACCCCAAAAAAAAAAAA","............((((...))))...((((...))))............"],
  hp3:["GGGCAGCUUCGGCUGCCCAAAA","(((((((...))))))).....",],
  hp53:["AAAAAGGGCAGCUUCGGCUGCCCAAAAA",".....(((((((...)))))))......",],
  three:["AAAAAAGGGGAAACCCCUGGGGAAAACCCCUUGGGGAAACCCCAAAAAAA","......((((...)))).((((....))))..((((...)))).......",],
  wide:["AAAAGGAAAAAAAAAACCGGGGAAACCCCAAAAAAAA","....((..........))((((...))))........",],
  two:["AAAAGGGGAAACCCCUUUGGGGAAACCCCAAAA","....((((...))))...((((...))))....",],
};
const out={};
for(const [name,[s,d]] of Object.entries(cases)){
  for(const mode of ["natural","flatten","L","perp"]){
    const {run}=load(file);
    run(`$("seq").value="${s}"; $("dot").value="${d}"; $("cCircle").checked=true; $("numEvery").value=5; $("render").click();
         $("tailMode").value="${mode}"; $("tailMode").onchange();`);
    out[name+"_"+mode]=run(`return {x:M.x.map(v=>+v.toFixed(2)), y:M.y.map(v=>+v.toFixed(2))}`);
    fs.writeFileSync(`tails/${tag}_${name}_${mode}.svg`, run(`return buildExportSVG().svg`));
  }
}
fs.writeFileSync(`tails/${tag}.json`,JSON.stringify(out));
process.exit(0);
